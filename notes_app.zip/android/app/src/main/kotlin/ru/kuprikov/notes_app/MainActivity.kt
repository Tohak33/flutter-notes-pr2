package ru.kuprikov.notes_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
